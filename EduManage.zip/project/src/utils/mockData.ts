import { Student, Announcement } from '../types';

const grades = ['8', '9', '10', '11', '12'];
const sections = ['A', 'B', 'C', 'D'];

const firstNames = [
  'Emma', 'Liam', 'Olivia', 'Noah', 'Ava', 'William', 'Sophia', 'James', 'Isabella', 'Oliver',
  'Charlotte', 'Benjamin', 'Amelia', 'Elijah', 'Mia', 'Lucas', 'Harper', 'Mason', 'Evelyn', 'Logan',
  'Abigail', 'Alexander', 'Emily', 'Ethan', 'Elizabeth', 'Jacob', 'Sofia', 'Michael', 'Avery', 'Daniel',
  'Ella', 'Henry', 'Scarlett', 'Jackson', 'Grace', 'Sebastian', 'Chloe', 'Aiden', 'Victoria', 'Matthew',
  'Riley', 'Samuel', 'Aria', 'David', 'Lily', 'Joseph', 'Aubrey', 'Carter', 'Zoey', 'Owen'
];

const lastNames = [
  'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez',
  'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson', 'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin',
  'Lee', 'Perez', 'Thompson', 'White', 'Harris', 'Sanchez', 'Clark', 'Ramirez', 'Lewis', 'Robinson',
  'Walker', 'Young', 'Allen', 'King', 'Wright', 'Scott', 'Torres', 'Nguyen', 'Hill', 'Flores',
  'Green', 'Adams', 'Nelson', 'Baker', 'Hall', 'Rivera', 'Campbell', 'Mitchell', 'Carter', 'Roberts'
];

const guardianFirstNames = [
  'John', 'Mary', 'Robert', 'Patricia', 'Michael', 'Jennifer', 'William', 'Linda', 'David', 'Elizabeth',
  'Richard', 'Barbara', 'Joseph', 'Susan', 'Thomas', 'Jessica', 'Charles', 'Sarah', 'Christopher', 'Karen',
  'Daniel', 'Nancy', 'Matthew', 'Lisa', 'Anthony', 'Margaret', 'Mark', 'Betty', 'Donald', 'Sandra',
  'Steven', 'Ashley', 'Paul', 'Dorothy', 'Andrew', 'Kimberly', 'Joshua', 'Emily', 'Kenneth', 'Donna',
  'Kevin', 'Michelle', 'Brian', 'Carol', 'George', 'Amanda', 'Edward', 'Melissa', 'Ronald', 'Deborah'
];

const cities = [
  'New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 'Philadelphia', 'San Antonio', 'San Diego',
  'Dallas', 'San Jose', 'Austin', 'Jacksonville', 'Fort Worth', 'Columbus', 'San Francisco', 'Charlotte',
  'Indianapolis', 'Seattle', 'Denver', 'Washington DC', 'Boston', 'El Paso', 'Nashville', 'Detroit',
  'Portland', 'Memphis', 'Oklahoma City', 'Las Vegas', 'Louisville', 'Baltimore'
];

const streetNames = [
  'Main St', 'Oak Ave', 'Maple Rd', 'Cedar Ln', 'Pine St', 'Washington Ave', 'Park Blvd', 'Lake Dr',
  'Elm St', 'River Rd', 'Church St', 'Highland Ave', 'Sunset Dr', 'Forest Ave', 'Meadow Ln',
  'Valley Rd', 'Spring St', 'Broadway', 'Hill St', 'Lincoln Ave', 'Franklin St', 'Jefferson Ave',
  'College St', 'Madison Ave', 'Willow Dr', 'Dogwood Ln', 'Cherry St', 'Center St', 'Orchard Ln',
  'School St'
];

// Generate a random date within the past 3 years
const getRandomDate = (yearsBack = 3) => {
  const today = new Date();
  const pastDate = new Date(today);
  pastDate.setFullYear(pastDate.getFullYear() - yearsBack);
  
  const randomTime = pastDate.getTime() + Math.random() * (today.getTime() - pastDate.getTime());
  return new Date(randomTime).toISOString();
};

// Generate a random integer between min and max (inclusive)
const getRandomInt = (min: number, max: number) => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

// Generate a random phone number
const generatePhone = () => {
  return `(${getRandomInt(100, 999)}) ${getRandomInt(100, 999)}-${getRandomInt(1000, 9999)}`;
};

// Generate a random email based on name
const generateEmail = (firstName: string, lastName: string) => {
  const domains = ['gmail.com', 'yahoo.com', 'outlook.com', 'icloud.com', 'hotmail.com'];
  const randomDomain = domains[Math.floor(Math.random() * domains.length)];
  return `${firstName.toLowerCase()}.${lastName.toLowerCase()}@${randomDomain}`;
};

// Generate a random address
const generateAddress = () => {
  const streetNumber = getRandomInt(100, 9999);
  const streetName = streetNames[Math.floor(Math.random() * streetNames.length)];
  const city = cities[Math.floor(Math.random() * cities.length)];
  const zipCode = getRandomInt(10000, 99999);
  return `${streetNumber} ${streetName}, ${city}, ${zipCode}`;
};

// Generate mock students data
export const generateMockStudents = (count: number): Student[] => {
  const students: Student[] = [];

  for (let i = 0; i < count; i++) {
    const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
    const guardianFirstName = guardianFirstNames[Math.floor(Math.random() * guardianFirstNames.length)];
    const guardianLastName = lastName; // Same last name as student
    
    const grade = grades[Math.floor(Math.random() * grades.length)];
    const classSection = sections[Math.floor(Math.random() * sections.length)];
    
    const totalDays = getRandomInt(150, 180);
    const presentDays = getRandomInt(Math.floor(totalDays * 0.7), totalDays);
    
    students.push({
      id: `STU${i.toString().padStart(3, '0')}`,
      fullName: `${firstName} ${lastName}`,
      grade,
      classSection,
      email: generateEmail(firstName, lastName),
      phone: generatePhone(),
      guardianName: `${guardianFirstName} ${guardianLastName}`,
      address: generateAddress(),
      attendance: {
        present: presentDays,
        absent: totalDays - presentDays,
        total: totalDays
      },
      performanceScore: Math.round(Math.random() * 10 * 10) / 10, // 0-10 score with one decimal
      joinedDate: getRandomDate(),
      gender: Math.random() > 0.5 ? 'Male' : 'Female',
      imageUrl: i % 5 === 0 ? `https://i.pravatar.cc/150?img=${i % 70}` : undefined, // Only some students have photos
    });
  }

  return students;
};

// Generate mock announcements
export const generateMockAnnouncements = (count: number): Announcement[] => {
  const announcementTitles = [
    'School Closure Due to Weather',
    'Parent-Teacher Conference Schedule',
    'Annual Sports Day',
    'Science Fair Registration Open',
    'Upcoming Holiday Schedule',
    'New School Policies',
    'Library Book Return Reminder',
    'Graduation Ceremony Details',
    'School Trip Permission Forms Due',
    'COVID-19 Safety Protocols Update',
    'School Play Auditions',
    'College Admission Counselors Visit',
    'Math Competition Registration',
    'End of Term Exam Schedule',
    'Summer School Registration'
  ];

  const announcementContents = [
    'Due to the severe weather forecast, the school will remain closed on Monday, March 15. All activities and classes are cancelled. Stay safe!',
    'We are pleased to announce the schedule for the upcoming parent-teacher conferences. Please sign up for a time slot using the online portal by Friday.',
    'The annual sports day will be held on April 20 at the school grounds. Students should come in their PE uniforms. Parents are welcome to attend and cheer for their children.',
    'The Science Fair registration is now open. Students interested in participating should submit their project proposals to their science teachers by next week.',
    'Please note the upcoming holidays: March 15 (Teachers\' Day), March 20-24 (Spring Break). Classes will resume on March 27.',
    'The school board has approved new policies regarding electronic device usage. Please review the updated student handbook on our website.',
    'All library books must be returned by May 20. Students with overdue books will not receive their report cards until all items are returned or fees paid.',
    'The graduation ceremony for the Class of 2023 will be held on June 15 at 2 PM in the school auditorium. Each graduate will receive 4 guest tickets.',
    'Permission forms for the upcoming history museum trip must be submitted by this Friday. No student will be allowed to participate without a signed form.',
    'We have updated our COVID-19 safety protocols. Masks are now optional but recommended. Hand sanitizing stations remain available throughout the campus.',
    'Auditions for the school play "Romeo and Juliet" will be held next Tuesday and Wednesday after school in the auditorium. All grades are welcome to participate.',
    'Representatives from leading universities will visit our school next month. Juniors and seniors interested in attending the sessions should register with the guidance office.',
    'The regional math competition registration deadline is approaching. Interested students should contact Mr. Johnson for details and practice sessions.',
    'The end of term examination schedule has been posted on the notice board. Please note that there have been some changes from the preliminary schedule.',
    'Summer school registration is now open. Courses offered include Algebra, Biology, English Literature, and Spanish. Space is limited, so register early.'
  ];

  const announcements: Announcement[] = [];

  for (let i = 0; i < count; i++) {
    const randomIndex = Math.floor(Math.random() * announcementTitles.length);
    
    announcements.push({
      id: `ANN${i.toString().padStart(3, '0')}`,
      title: announcementTitles[randomIndex],
      content: announcementContents[randomIndex],
      date: getRandomDate(1), // Within the past year
      author: 'School Administration',
      important: Math.random() > 0.7 // 30% chance of being important
    });
    
    // Remove used announcement to avoid duplicates
    announcementTitles.splice(randomIndex, 1);
    announcementContents.splice(randomIndex, 1);
    
    if (announcementTitles.length === 0) break;
  }

  return announcements;
};