import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import StudentsList from './pages/StudentsList';
import StudentDetail from './pages/StudentDetail';
import Announcements from './pages/Announcements';
import Settings from './pages/Settings';
import { StudentsProvider } from './context/StudentsContext';
import { AnnouncementsProvider } from './context/AnnouncementsContext';

function App() {
  return (
    <StudentsProvider>
      <AnnouncementsProvider>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Dashboard />} />
            <Route path="students" element={<StudentsList />} />
            <Route path="students/:id" element={<StudentDetail />} />
            <Route path="announcements" element={<Announcements />} />
            <Route path="settings" element={<Settings />} />
          </Route>
        </Routes>
      </AnnouncementsProvider>
    </StudentsProvider>
  );
}

export default App;