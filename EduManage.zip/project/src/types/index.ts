export interface Student {
  id: string;
  fullName: string;
  grade: string;
  classSection: string;
  email: string;
  phone: string;
  guardianName: string;
  address: string;
  attendance: {
    present: number;
    absent: number;
    total: number;
  };
  performanceScore: number;
  joinedDate: string;
  gender: 'Male' | 'Female' | 'Other';
  imageUrl?: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  date: string;
  author: string;
  important: boolean;
}

export type SortDirection = 'asc' | 'desc';

export interface SortConfig {
  key: keyof Student;
  direction: SortDirection;
}

export interface FilterConfig {
  grade: string;
  classSection: string;
  searchQuery: string;
}