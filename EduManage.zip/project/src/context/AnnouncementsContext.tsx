import { createContext, useContext, useState, useEffect } from 'react';
import { Announcement } from '../types';
import { generateMockAnnouncements } from '../utils/mockData';

interface AnnouncementsContextType {
  announcements: Announcement[];
  addAnnouncement: (announcement: Omit<Announcement, 'id'>) => void;
  updateAnnouncement: (id: string, announcement: Partial<Announcement>) => void;
  deleteAnnouncement: (id: string) => void;
  getAnnouncementById: (id: string) => Announcement | undefined;
}

const AnnouncementsContext = createContext<AnnouncementsContextType | undefined>(undefined);

export const AnnouncementsProvider = ({ children }: { children: React.ReactNode }) => {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);

  // Initialize with mock data
  useEffect(() => {
    const mockAnnouncements = generateMockAnnouncements(5);
    setAnnouncements(mockAnnouncements);
  }, []);

  const addAnnouncement = (announcement: Omit<Announcement, 'id'>) => {
    const newAnnouncement = {
      ...announcement,
      id: Math.random().toString(36).substr(2, 9),
    };
    setAnnouncements(prev => [newAnnouncement as Announcement, ...prev]);
  };

  const updateAnnouncement = (id: string, announcement: Partial<Announcement>) => {
    setAnnouncements(prev =>
      prev.map(a => (a.id === id ? { ...a, ...announcement } : a))
    );
  };

  const deleteAnnouncement = (id: string) => {
    setAnnouncements(prev => prev.filter(a => a.id !== id));
  };

  const getAnnouncementById = (id: string) => {
    return announcements.find(a => a.id === id);
  };

  return (
    <AnnouncementsContext.Provider
      value={{
        announcements,
        addAnnouncement,
        updateAnnouncement,
        deleteAnnouncement,
        getAnnouncementById,
      }}
    >
      {children}
    </AnnouncementsContext.Provider>
  );
};

export const useAnnouncements = () => {
  const context = useContext(AnnouncementsContext);
  if (context === undefined) {
    throw new Error('useAnnouncements must be used within an AnnouncementsProvider');
  }
  return context;
};