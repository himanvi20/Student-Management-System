import { createContext, useContext, useState, useEffect } from 'react';
import { Student, SortConfig, FilterConfig } from '../types';
import { generateMockStudents } from '../utils/mockData';

interface StudentsContextType {
  students: Student[];
  filteredStudents: Student[];
  getStudentById: (id: string) => Student | undefined;
  sortConfig: SortConfig;
  setSortConfig: (config: SortConfig) => void;
  filterConfig: FilterConfig;
  setFilterConfig: (config: Partial<FilterConfig>) => void;
  addStudent: (student: Omit<Student, 'id'>) => void;
  updateStudent: (id: string, studentData: Partial<Student>) => void;
  deleteStudent: (id: string) => void;
}

const StudentsContext = createContext<StudentsContextType | undefined>(undefined);

export const StudentsProvider = ({ children }: { children: React.ReactNode }) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [sortConfig, setSortConfig] = useState<SortConfig>({
    key: 'fullName',
    direction: 'asc',
  });
  const [filterConfig, setFilterConfig] = useState<FilterConfig>({
    grade: '',
    classSection: '',
    searchQuery: '',
  });

  // Initialize with mock data
  useEffect(() => {
    const mockStudents = generateMockStudents(100);
    setStudents(mockStudents);
  }, []);

  // Apply filters and sorting
  const filteredStudents = students
    .filter((student) => {
      const matchesGrade = !filterConfig.grade || student.grade === filterConfig.grade;
      const matchesClass = !filterConfig.classSection || student.classSection === filterConfig.classSection;
      const matchesSearch = !filterConfig.searchQuery || 
        student.fullName.toLowerCase().includes(filterConfig.searchQuery.toLowerCase()) ||
        student.email.toLowerCase().includes(filterConfig.searchQuery.toLowerCase());
      
      return matchesGrade && matchesClass && matchesSearch;
    })
    .sort((a, b) => {
      const key = sortConfig.key;
      
      if (typeof a[key] === 'string' && typeof b[key] === 'string') {
        const aString = a[key] as string;
        const bString = b[key] as string;
        
        return sortConfig.direction === 'asc' 
          ? aString.localeCompare(bString) 
          : bString.localeCompare(aString);
      }
      
      return 0;
    });

  const getStudentById = (id: string) => {
    return students.find(student => student.id === id);
  };

  const handleSetFilterConfig = (config: Partial<FilterConfig>) => {
    setFilterConfig(prev => ({ ...prev, ...config }));
  };

  const addStudent = (student: Omit<Student, 'id'>) => {
    const newStudent = {
      ...student,
      id: Math.random().toString(36).substr(2, 9)
    };
    setStudents(prev => [...prev, newStudent as Student]);
  };

  const updateStudent = (id: string, studentData: Partial<Student>) => {
    setStudents(prev => 
      prev.map(student => 
        student.id === id ? { ...student, ...studentData } : student
      )
    );
  };

  const deleteStudent = (id: string) => {
    setStudents(prev => prev.filter(student => student.id !== id));
  };

  return (
    <StudentsContext.Provider
      value={{
        students,
        filteredStudents,
        getStudentById,
        sortConfig,
        setSortConfig,
        filterConfig,
        setFilterConfig: handleSetFilterConfig,
        addStudent,
        updateStudent,
        deleteStudent,
      }}
    >
      {children}
    </StudentsContext.Provider>
  );
};

export const useStudents = () => {
  const context = useContext(StudentsContext);
  if (context === undefined) {
    throw new Error('useStudents must be used within a StudentsProvider');
  }
  return context;
};