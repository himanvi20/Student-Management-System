import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowDown, ArrowUp, Search } from 'lucide-react';
import { Student, SortConfig, FilterConfig } from '../types';

interface StudentTableProps {
  students: Student[];
  sortConfig: SortConfig;
  onSort: (key: keyof Student) => void;
  filterConfig: FilterConfig;
  onFilterChange: (filter: Partial<FilterConfig>) => void;
}

const StudentTable = ({ 
  students, 
  sortConfig, 
  onSort,
  filterConfig,
  onFilterChange
}: StudentTableProps) => {
  const [visibleColumns, setVisibleColumns] = useState<(keyof Student)[]>([
    'fullName', 'grade', 'classSection', 'email', 'guardianName'
  ]);

  // Get unique grades and class sections for filters
  const grades = Array.from(new Set(students.map(s => s.grade))).sort();
  const classSections = Array.from(new Set(students.map(s => s.classSection))).sort();

  const renderSortIcon = (key: keyof Student) => {
    if (sortConfig.key !== key) return null;
    return sortConfig.direction === 'asc' ? (
      <ArrowUp className="h-4 w-4" />
    ) : (
      <ArrowDown className="h-4 w-4" />
    );
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFilterChange({ searchQuery: e.target.value });
  };

  return (
    <div className="flex flex-col">
      <div className="mb-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {/* Search */}
        <div className="relative rounded-md shadow-sm">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
            placeholder="Search students..."
            value={filterConfig.searchQuery}
            onChange={handleSearch}
          />
        </div>

        {/* Grade Filter */}
        <div>
          <select
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
            value={filterConfig.grade}
            onChange={(e) => onFilterChange({ grade: e.target.value })}
          >
            <option value="">All Grades</option>
            {grades.map(grade => (
              <option key={grade} value={grade}>{grade}</option>
            ))}
          </select>
        </div>

        {/* Class Section Filter */}
        <div>
          <select
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
            value={filterConfig.classSection}
            onChange={(e) => onFilterChange({ classSection: e.target.value })}
          >
            <option value="">All Sections</option>
            {classSections.map(section => (
              <option key={section} value={section}>{section}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
        <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
          <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  {visibleColumns.includes('fullName') && (
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                      onClick={() => onSort('fullName')}
                    >
                      <div className="flex items-center">
                        <span>Name</span>
                        {renderSortIcon('fullName')}
                      </div>
                    </th>
                  )}
                  {visibleColumns.includes('grade') && (
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                      onClick={() => onSort('grade')}
                    >
                      <div className="flex items-center">
                        <span>Grade</span>
                        {renderSortIcon('grade')}
                      </div>
                    </th>
                  )}
                  {visibleColumns.includes('classSection') && (
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                      onClick={() => onSort('classSection')}
                    >
                      <div className="flex items-center">
                        <span>Section</span>
                        {renderSortIcon('classSection')}
                      </div>
                    </th>
                  )}
                  {visibleColumns.includes('email') && (
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                      onClick={() => onSort('email')}
                    >
                      <div className="flex items-center">
                        <span>Email</span>
                        {renderSortIcon('email')}
                      </div>
                    </th>
                  )}
                  {visibleColumns.includes('guardianName') && (
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                      onClick={() => onSort('guardianName')}
                    >
                      <div className="flex items-center">
                        <span>Guardian</span>
                        {renderSortIcon('guardianName')}
                      </div>
                    </th>
                  )}
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {students.map((student) => (
                  <tr 
                    key={student.id}
                    className="hover:bg-gray-50 cursor-pointer transition-colors"
                  >
                    {visibleColumns.includes('fullName') && (
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Link to={`/students/${student.id}`} className="flex items-center">
                          {student.imageUrl ? (
                            <img 
                              className="h-8 w-8 rounded-full object-cover" 
                              src={student.imageUrl} 
                              alt="" 
                            />
                          ) : (
                            <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center text-white">
                              {student.fullName.charAt(0)}
                            </div>
                          )}
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{student.fullName}</div>
                          </div>
                        </Link>
                      </td>
                    )}
                    {visibleColumns.includes('grade') && (
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{student.grade}</div>
                      </td>
                    )}
                    {visibleColumns.includes('classSection') && (
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{student.classSection}</div>
                      </td>
                    )}
                    {visibleColumns.includes('email') && (
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{student.email}</div>
                      </td>
                    )}
                    {visibleColumns.includes('guardianName') && (
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{student.guardianName}</div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentTable;