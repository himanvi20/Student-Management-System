import { formatDistanceToNow } from 'date-fns';
import { Announcement } from '../types';
import { AlertCircle } from 'lucide-react';

interface AnnouncementCardProps {
  announcement: Announcement;
}

const AnnouncementCard = ({ announcement }: AnnouncementCardProps) => {
  return (
    <div className={`border-l-4 ${announcement.important ? 'border-red-500' : 'border-blue-500'} bg-white rounded-lg shadow-sm p-5 mb-4`}>
      <div className="flex items-start">
        <div className="flex-1">
          <div className="flex items-center mb-2">
            {announcement.important && (
              <AlertCircle className="h-4 w-4 text-red-500 mr-2" />
            )}
            <h3 className="text-lg font-medium text-gray-900">{announcement.title}</h3>
          </div>
          <p className="text-gray-600 mb-3">{announcement.content}</p>
          <div className="flex items-center text-sm text-gray-500">
            <span>{announcement.author}</span>
            <span className="mx-2">•</span>
            <span>{formatDistanceToNow(new Date(announcement.date), { addSuffix: true })}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnnouncementCard;