import { User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Student } from '../types';

interface StudentCardProps {
  student: Student;
}

const StudentCard = ({ student }: StudentCardProps) => {
  const attendancePercentage = 
    student.attendance.total > 0
      ? Math.round((student.attendance.present / student.attendance.total) * 100)
      : 0;

  return (
    <Link 
      to={`/students/${student.id}`}
      className="block bg-white rounded-lg shadow-sm overflow-hidden transition-transform hover:scale-[1.02] hover:shadow-md"
    >
      <div className="p-5">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            {student.imageUrl ? (
              <img 
                className="h-12 w-12 rounded-full object-cover" 
                src={student.imageUrl} 
                alt={student.fullName} 
              />
            ) : (
              <div className="h-12 w-12 rounded-full bg-blue-600 flex items-center justify-center text-white">
                <User className="h-6 w-6" />
              </div>
            )}
          </div>
          <div className="ml-4">
            <h3 className="text-lg font-medium text-gray-900">{student.fullName}</h3>
            <div className="text-sm text-gray-500">
              Grade {student.grade}, Section {student.classSection}
            </div>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-4">
          <div>
            <div className="text-xs font-medium text-gray-500 uppercase tracking-wider">
              Attendance
            </div>
            <div className="mt-1">
              <div className="flex items-center">
                <div className="flex-1 bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${
                      attendancePercentage >= 75 ? 'bg-green-500' : 
                      attendancePercentage >= 50 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${attendancePercentage}%` }}
                  />
                </div>
                <span className="ml-2 text-sm font-medium text-gray-700">
                  {attendancePercentage}%
                </span>
              </div>
            </div>
          </div>
          <div>
            <div className="text-xs font-medium text-gray-500 uppercase tracking-wider">
              Performance
            </div>
            <div className="mt-1 text-sm font-medium text-gray-900">
              {student.performanceScore}/10
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default StudentCard;