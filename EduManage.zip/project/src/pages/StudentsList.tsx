import { useState } from 'react';
import { useStudents } from '../context/StudentsContext';
import StudentTable from '../components/StudentTable';
import { UserPlus, Users, LayoutGrid, LayoutList } from 'lucide-react';
import StudentCard from '../components/StudentCard';

const StudentsList = () => {
  const { filteredStudents, sortConfig, setSortConfig, filterConfig, setFilterConfig } = useStudents();
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');

  const handleSort = (key: keyof typeof filteredStudents[0]) => {
    setSortConfig({
      key,
      direction: sortConfig.key === key && sortConfig.direction === 'asc' ? 'desc' : 'asc',
    });
  };

  return (
    <div className="py-6">
      <div className="flex flex-col space-y-6">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-4 sm:space-y-0">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">Students</h1>
            <p className="mt-1 text-sm text-gray-500">
              Manage and view student records
            </p>
          </div>

          <div className="flex space-x-3">
            <div className="flex rounded-md shadow-sm">
              <button
                type="button"
                onClick={() => setViewMode('table')}
                className={`relative inline-flex items-center rounded-l-md px-3 py-2 text-sm font-medium ${
                  viewMode === 'table'
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                } border border-gray-300 focus:z-10 focus:outline-none`}
              >
                <LayoutList className="h-4 w-4 mr-2" />
                Table
              </button>
              <button
                type="button"
                onClick={() => setViewMode('grid')}
                className={`relative -ml-px inline-flex items-center rounded-r-md px-3 py-2 text-sm font-medium ${
                  viewMode === 'grid'
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                } border border-gray-300 focus:z-10 focus:outline-none`}
              >
                <LayoutGrid className="h-4 w-4 mr-2" />
                Grid
              </button>
            </div>

            <button
              type="button"
              className="inline-flex items-center rounded-md bg-blue-600 px-3 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none"
            >
              <UserPlus className="h-4 w-4 mr-2" />
              Add Student
            </button>
          </div>
        </div>

        {/* Student Count */}
        <div className="flex items-center">
          <Users className="h-5 w-5 text-gray-500" />
          <span className="ml-2 text-sm text-gray-700">
            {filteredStudents.length} students
          </span>
        </div>

        {/* Students List */}
        {viewMode === 'table' ? (
          <StudentTable
            students={filteredStudents}
            sortConfig={sortConfig}
            onSort={handleSort}
            filterConfig={filterConfig}
            onFilterChange={setFilterConfig}
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredStudents.map(student => (
              <StudentCard key={student.id} student={student} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default StudentsList;