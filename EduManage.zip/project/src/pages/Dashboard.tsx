import { Users, BookOpen, Calendar, Bell } from 'lucide-react';
import { useStudents } from '../context/StudentsContext';
import { useAnnouncements } from '../context/AnnouncementsContext';
import StatCard from '../components/StatCard';
import StudentCard from '../components/StudentCard';
import AnnouncementCard from '../components/AnnouncementCard';

const Dashboard = () => {
  const { students } = useStudents();
  const { announcements } = useAnnouncements();

  // Calculate statistics
  const totalStudents = students.length;
  
  const attendanceStats = students.reduce(
    (acc, student) => {
      const totalDays = student.attendance.total;
      const presentDays = student.attendance.present;
      
      acc.totalDays += totalDays;
      acc.presentDays += presentDays;
      
      return acc;
    },
    { totalDays: 0, presentDays: 0 }
  );
  
  const averageAttendance = attendanceStats.totalDays > 0
    ? Math.round((attendanceStats.presentDays / attendanceStats.totalDays) * 100)
    : 0;
  
  const gradeDistribution = students.reduce((acc, student) => {
    acc[student.grade] = (acc[student.grade] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  
  // Get top grades
  const topGrade = Object.entries(gradeDistribution)
    .sort((a, b) => b[1] - a[1])
    .map(([grade]) => grade)[0] || 'N/A';

  // Get recent announcements (max 3)
  const recentAnnouncements = [...announcements]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 3);

  // Get top performing students (max 3)
  const topStudents = [...students]
    .sort((a, b) => b.performanceScore - a.performanceScore)
    .slice(0, 3);

  return (
    <div className="py-6">
      <div className="flex flex-col space-y-6">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
          <p className="mt-1 text-sm text-gray-500">
            Overview of student data and school announcements
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total Students"
            value={totalStudents}
            icon={<Users className="h-5 w-5" />}
            color="blue"
          />
          <StatCard
            title="Average Attendance"
            value={`${averageAttendance}%`}
            icon={<Calendar className="h-5 w-5" />}
            color="green"
          />
          <StatCard
            title="Largest Grade"
            value={topGrade}
            description={`${gradeDistribution[topGrade] || 0} students`}
            icon={<BookOpen className="h-5 w-5" />}
            color="yellow"
          />
          <StatCard
            title="Announcements"
            value={announcements.length}
            description={`${announcements.filter(a => a.important).length} important`}
            icon={<Bell className="h-5 w-5" />}
            color="red"
          />
        </div>

        {/* Main content */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Recent Announcements */}
          <div className="lg:col-span-2">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Recent Announcements</h2>
            <div className="space-y-4">
              {recentAnnouncements.length > 0 ? (
                recentAnnouncements.map(announcement => (
                  <AnnouncementCard key={announcement.id} announcement={announcement} />
                ))
              ) : (
                <p className="text-gray-500">No announcements available.</p>
              )}
            </div>
          </div>

          {/* Top Students */}
          <div>
            <h2 className="text-lg font-medium text-gray-900 mb-4">Top Performing Students</h2>
            <div className="space-y-4">
              {topStudents.map(student => (
                <StudentCard key={student.id} student={student} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;