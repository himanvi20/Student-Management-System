import { useState } from 'react';
import { useAnnouncements } from '../context/AnnouncementsContext';
import AnnouncementCard from '../components/AnnouncementCard';
import AnnouncementForm from '../components/AnnouncementForm';
import { Plus, X } from 'lucide-react';

const Announcements = () => {
  const { announcements, addAnnouncement } = useAnnouncements();
  const [showForm, setShowForm] = useState(false);

  const handleAddAnnouncement = (announcement: any) => {
    addAnnouncement(announcement);
    setShowForm(false);
  };

  return (
    <div className="py-6">
      <div className="flex flex-col space-y-6">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-4 sm:space-y-0">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">Announcements</h1>
            <p className="mt-1 text-sm text-gray-500">
              View and manage school announcements
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowForm(!showForm)}
            className="inline-flex items-center rounded-md bg-blue-600 px-3 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none"
          >
            {showForm ? (
              <>
                <X className="h-4 w-4 mr-2" />
                Cancel
              </>
            ) : (
              <>
                <Plus className="h-4 w-4 mr-2" />
                New Announcement
              </>
            )}
          </button>
        </div>

        {/* Announcement Form */}
        {showForm && (
          <div className="bg-white shadow overflow-hidden sm:rounded-lg p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Create New Announcement</h2>
            <AnnouncementForm onSubmit={handleAddAnnouncement} />
          </div>
        )}

        {/* Announcements List */}
        <div className="space-y-4">
          {announcements.length > 0 ? (
            announcements.map(announcement => (
              <AnnouncementCard key={announcement.id} announcement={announcement} />
            ))
          ) : (
            <p className="text-gray-500">No announcements available.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Announcements;