import { useParams, Link } from 'react-router-dom';
import { useStudents } from '../context/StudentsContext';
import { ArrowLeft, User, Mail, Phone, Home, Calendar, BookOpen, Users } from 'lucide-react';

const StudentDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { getStudentById } = useStudents();
  const student = getStudentById(id || '');

  if (!student) {
    return (
      <div className="py-6">
        <div className="bg-white shadow overflow-hidden sm:rounded-lg p-6">
          <div className="text-center">
            <h3 className="text-lg font-medium text-gray-900">Student not found</h3>
            <p className="mt-1 text-sm text-gray-500">
              The student you're looking for doesn't exist or has been removed.
            </p>
            <Link
              to="/students"
              className="mt-4 inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-500"
            >
              <ArrowLeft className="h-4 w-4 mr-1" />
              Back to students list
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const attendancePercentage = 
    student.attendance.total > 0
      ? Math.round((student.attendance.present / student.attendance.total) * 100)
      : 0;

  return (
    <div className="py-6">
      <div className="flex flex-col space-y-6">
        <div>
          <Link
            to="/students"
            className="inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-500"
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to students list
          </Link>
        </div>

        <div className="bg-white shadow overflow-hidden sm:rounded-lg">
          <div className="px-4 py-5 sm:px-6 flex items-center justify-between">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                {student.imageUrl ? (
                  <img
                    className="h-16 w-16 rounded-full object-cover"
                    src={student.imageUrl}
                    alt={student.fullName}
                  />
                ) : (
                  <div className="h-16 w-16 rounded-full bg-blue-600 flex items-center justify-center text-white">
                    <User className="h-8 w-8" />
                  </div>
                )}
              </div>
              <div className="ml-5">
                <h3 className="text-lg font-medium text-gray-900">{student.fullName}</h3>
                <p className="text-sm text-gray-500">ID: {student.id}</p>
              </div>
            </div>
            <div className="flex space-x-3">
              <button
                type="button"
                className="inline-flex items-center rounded-md bg-white px-3 py-2 text-sm font-medium text-gray-700 shadow-sm border border-gray-300 hover:bg-gray-50 focus:outline-none"
              >
                Edit
              </button>
            </div>
          </div>

          <div className="border-t border-gray-200 px-4 py-5 sm:p-0">
            <dl className="sm:divide-y sm:divide-gray-200">
              <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5 sm:px-6">
                <dt className="text-sm font-medium text-gray-500 flex items-center">
                  <Mail className="h-4 w-4 mr-2" />
                  Email
                </dt>
                <dd className="mt-1 text-sm text-gray-900 sm:col-span-2 sm:mt-0">
                  {student.email}
                </dd>
              </div>
              <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5 sm:px-6">
                <dt className="text-sm font-medium text-gray-500 flex items-center">
                  <Phone className="h-4 w-4 mr-2" />
                  Phone number
                </dt>
                <dd className="mt-1 text-sm text-gray-900 sm:col-span-2 sm:mt-0">
                  {student.phone}
                </dd>
              </div>
              <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5 sm:px-6">
                <dt className="text-sm font-medium text-gray-500 flex items-center">
                  <BookOpen className="h-4 w-4 mr-2" />
                  Grade & Class
                </dt>
                <dd className="mt-1 text-sm text-gray-900 sm:col-span-2 sm:mt-0">
                  Grade {student.grade}, Section {student.classSection}
                </dd>
              </div>
              <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5 sm:px-6">
                <dt className="text-sm font-medium text-gray-500 flex items-center">
                  <Users className="h-4 w-4 mr-2" />
                  Guardian
                </dt>
                <dd className="mt-1 text-sm text-gray-900 sm:col-span-2 sm:mt-0">
                  {student.guardianName}
                </dd>
              </div>
              <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5 sm:px-6">
                <dt className="text-sm font-medium text-gray-500 flex items-center">
                  <Home className="h-4 w-4 mr-2" />
                  Address
                </dt>
                <dd className="mt-1 text-sm text-gray-900 sm:col-span-2 sm:mt-0">
                  {student.address}
                </dd>
              </div>
              <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5 sm:px-6">
                <dt className="text-sm font-medium text-gray-500 flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  Joined Date
                </dt>
                <dd className="mt-1 text-sm text-gray-900 sm:col-span-2 sm:mt-0">
                  {new Date(student.joinedDate).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </dd>
              </div>
            </dl>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          {/* Attendance Card */}
          <div className="bg-white shadow overflow-hidden sm:rounded-lg">
            <div className="px-4 py-5 sm:px-6">
              <h3 className="text-lg font-medium text-gray-900">Attendance</h3>
              <p className="mt-1 max-w-2xl text-sm text-gray-500">
                Student's attendance record
              </p>
            </div>
            <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
              <div className="flex items-center">
                <div className="flex-1">
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">
                      {attendancePercentage}% Attendance
                    </span>
                    <span className="text-sm font-medium text-gray-700">
                      {student.attendance.present}/{student.attendance.total} days
                    </span>
                  </div>
                  <div className="flex items-center">
                    <div className="flex-1 bg-gray-200 rounded-full h-3">
                      <div
                        className={`h-3 rounded-full ${
                          attendancePercentage >= 75 ? 'bg-green-500' : 
                          attendancePercentage >= 50 ? 'bg-yellow-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${attendancePercentage}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="mt-6 grid grid-cols-2 gap-4 text-center">
                <div className="border rounded-lg px-4 py-3 bg-green-50 border-green-200">
                  <div className="text-2xl font-bold text-green-600">
                    {student.attendance.present}
                  </div>
                  <div className="text-xs font-medium text-green-800 uppercase tracking-wider mt-1">
                    Days Present
                  </div>
                </div>
                <div className="border rounded-lg px-4 py-3 bg-red-50 border-red-200">
                  <div className="text-2xl font-bold text-red-600">
                    {student.attendance.absent}
                  </div>
                  <div className="text-xs font-medium text-red-800 uppercase tracking-wider mt-1">
                    Days Absent
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Performance Card */}
          <div className="bg-white shadow overflow-hidden sm:rounded-lg">
            <div className="px-4 py-5 sm:px-6">
              <h3 className="text-lg font-medium text-gray-900">Performance</h3>
              <p className="mt-1 max-w-2xl text-sm text-gray-500">
                Academic performance metrics
              </p>
            </div>
            <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
              <div className="flex items-center mb-6">
                <div className="flex-1">
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">
                      Performance Score
                    </span>
                    <span className="text-sm font-medium text-gray-700">
                      {student.performanceScore}/10
                    </span>
                  </div>
                  <div className="flex items-center">
                    <div className="flex-1 bg-gray-200 rounded-full h-3">
                      <div
                        className={`h-3 rounded-full ${
                          student.performanceScore >= 7.5 ? 'bg-green-500' : 
                          student.performanceScore >= 5 ? 'bg-yellow-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${student.performanceScore * 10}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="text-center border rounded-lg px-4 py-6 bg-blue-50 border-blue-200">
                <div className="text-sm font-medium text-blue-800 uppercase tracking-wider mb-1">
                  Performance Rating
                </div>
                <div className="text-3xl font-bold text-blue-600">
                  {student.performanceScore >= 7.5 
                    ? 'Excellent' 
                    : student.performanceScore >= 6 
                    ? 'Good' 
                    : student.performanceScore >= 5 
                    ? 'Average' 
                    : 'Needs Improvement'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDetail;